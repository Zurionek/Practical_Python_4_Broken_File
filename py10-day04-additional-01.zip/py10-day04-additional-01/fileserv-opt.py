import socket
import time
import hashlib
import struct
import sys

from fragtree import FRAG_SZ, make_tree


def recvall(s, sz):
  total = 0
  data = []

  while True:
    part_data = s.recv(sz - total)
    if not part_data:
      return None

    total += len(part_data)
    data.append(part_data)

    if total == sz:
      return b''.join(data)

# Start by making the tree before we start accepting clients.
with open("bigfile-server", "rb") as f:
  tree = make_tree(f)

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("0.0.0.0", 1234))
s.listen(10)
print("Listening on port 1234")

c, addr = s.accept()

print("CONNECTED:", addr)

HASH_OF_EMPTY = hashlib.sha256(b'').digest()
with open("bigfile", "rb") as f:
  while True:
    req = recvall(c, 5)
    if req is None:
      break

    level, frag = struct.unpack("<BI", req)

    if level == 255:
      # Special case - client requested actual data (not a hash).
      f.seek(frag * FRAG_SZ)
      fdata = f.read(FRAG_SZ)
      c.sendall(struct.pack("<I", len(fdata)))
      c.sendall(fdata)
      print(f"Client requested DATA for fragment {frag}. "
            f"Sent {len(fdata)} bytes.")
      continue

    if level >= len(tree) or frag >= len(tree[level]):
      # Client requested something that doesn't exist. Weird. Send back the
      # hash of empty data.
      print(f"WARNING: Client requested non-existant hash {level}.{frag}")
      c.sendall(HASH_OF_EMPTY)
      continue

    # Send the hash.
    print(f"Client requested hash for fragment {level}.{frag}")
    c.sendall(tree[level][frag])

c.shutdown(socket.SHUT_RDWR)
c.close()

s.close()
