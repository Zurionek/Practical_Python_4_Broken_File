import socket
import time
import hashlib
import struct

from fragtree import FRAG_SZ, make_tree

TOTAL_RECV = 0
TOTAL_SENT = 0

def recvall(s, sz):
  global TOTAL_RECV
  total = 0
  data = []

  while True:
    part_data = s.recv(sz - total)
    if not part_data:
      return None

    total += len(part_data)
    data.append(part_data)

    if total == sz:
      TOTAL_RECV += sz
      return b''.join(data)

def sendall(s, data):
  global TOTAL_SENT
  TOTAL_SENT += len(data)
  return s.sendall(data)

def fix_worker(f, s, tree, level, frag):
  spaces = " " * (len(tree) - level)
  print(f"{spaces}Probing {level}.{frag}...", end="")

  if level < 0:
    print("Fixing")
    sendall(s, struct.pack("<BI", 255, frag))
    frag_sz = recvall(s, 4)
    if not frag_sz:
      raise Exception("Client disconnected before we could finish")
    frag_sz = struct.unpack("<I", frag_sz)[0]
    if frag_sz != 0:
      frag_data = recvall(s, frag_sz)
      if not frag_data:
        raise Exception("Client disconnected before we could finish")

      f.seek(frag * FRAG_SZ)
      f.write(frag_data)
    return

  if level >= len(tree) or frag >= len(tree[level]):
    print("OOB")
    return  # Nothing to do.

  sendall(s, struct.pack("<BI", level, frag))
  hash_data = recvall(s, 32)
  if not hash_data:
    raise Exception("Client disconnected before we could finish")

  if hash_data == tree[level][frag]:
    print("OK")
    return  # Hashes match. Nothing to do.

  # Hashes didn't match, go deeper.
  print("MISMATCH")
  if level == 0:
    fix_worker(f, s, tree, -1, frag)  # Request data.
  else:
    fix_worker(f, s, tree, level - 1, frag * 2 + 0)
    fix_worker(f, s, tree, level - 1, frag * 2 + 1)


with open("bigfile-local", "r+b") as f:
  tree = make_tree(f)

  s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  s.connect(("127.0.0.1", 1234))
  print("CONNECTED")

  fix_worker(f, s, tree, len(tree) - 1, 0)
  fix_worker(f, s, tree, len(tree) - 1, 1)

s.close()
print("Done")
print("TOTAL_RECV:", TOTAL_RECV, "bytes")
print("TOTAL_SENT:", TOTAL_SENT, "bytes")
print("TOTAL     :", TOTAL_RECV + TOTAL_SENT, "bytes")
