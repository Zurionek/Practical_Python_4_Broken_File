import hashlib
FRAG_SZ = 64 # 1KB

def make_tree(f):
  tree = []  # A list of lists.

  # Make the first level, which contains all hashes of each fragment.
  # This is slow since we need to read the whole file...
  level0 = []
  print("Calculating level0 hashes...", end="", flush=True)
  old_offset = f.tell()
  while True:
    fdata = f.read(FRAG_SZ)
    if not fdata:
      break
    h = hashlib.sha256(fdata).digest()
    level0.append(h)

  f.seek(old_offset)
  print("OK")
  tree.append(level0)

  # Now create the next level, which is half the size, and we merge each 2
  # fragment hashes with each other. For "merging" we just calc the hash
  # of both hashes.
  # After that we calculate the next level, and the next...
  #
  # level0:      hash0_0, hash0_1, hash0_2, hash0_3, hash0_4, ...
  #                 \        /        \        /        \
  #                  \      /          \      /          \
  # level1:          hash1_0,          hash1_1,          hash1_2, ...
  #                     \                 /                 \
  #                      \               /                   \
  #                       \             /                     \
  #                        \           /                       \
  #                         \         /                         \
  #                          \       /                           \
  # level2:                   hash2_0                             hash2_1, ...
  # ...
  # ... and so on until we get to a level with only 2 hashes.

  print("Merging hash pairs...")
  while True:
    prev_level = tree[-1]
    if len(prev_level) == 2:
      break  # Only two hashes are left in the last level, so that's it.

    next_level = []
    i = 0
    while i < len(prev_level):
      hashP_I0 = prev_level[i]
      i += 1

      if i < len(prev_level):  # Second hash in the pair might be not there.
        hashP_I1 = prev_level[i]
        i += 1
      else:
        hashP_I1 = b''

      hashN = hashlib.sha256(hashP_I0 + hashP_I1).digest()  # Merge.
      next_level.append(hashN)

    tree.append(next_level)
    print(f"  Added level {len(tree)}: {len(next_level)} hashes")

  return tree
