MB = b'X' * (1024**2)

with open("bigfile-local", "wb") as f:
  for _ in range(1024):
    f.write(MB)

with open("bigfile-server", "wb") as f:
  for _ in range(1024):
    f.write(MB)
